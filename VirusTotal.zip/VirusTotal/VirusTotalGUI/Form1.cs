﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VirusTotalNET;
using VirusTotalNET.Objects;
using VirusTotalNET.ResponseCodes;
using VirusTotalNET.Results;



namespace VirusTotalGUI
{
    public partial class Form1 : Form
    {
        private Stream myStream;
        List<ScanResult> resultList = new List<ScanResult>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            AllocConsole();
            Debug.WriteLine("Application Started");
        }


        [DllImport("kernel32.dll", EntryPoint = "AllocConsole", SetLastError = true, CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool AllocConsole();





        private static void PrintScan(FileReport fileReport)

        {

            Console.WriteLine("Scan ID: " + fileReport.ScanId);

            Console.WriteLine("Message: " + fileReport.VerboseMsg);


            if (fileReport.ResponseCode == FileReportResponseCode.Present)

            {

                foreach (KeyValuePair<string, ScanEngine> scan in fileReport.Scans)

                {
                    Console.WriteLine("{0,-25} Detected: {1}", scan.Key, scan.Value.Detected);
                }
            }
            Console.ReadLine();
        }


        

        private void BrowseButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fileLocator.Text = openFileDialog1.FileName;
                myStream = openFileDialog1.OpenFile();
            }
        }

        private async void ScanButton_Click(object sender, EventArgs e)
        {
            try
            {

                if (myStream != null)
                {
                    using (myStream)
                    {
                        string API_KEY= System.Environment.GetEnvironmentVariable("API_KEY", EnvironmentVariableTarget.Machine);
                        VirusTotal virusTotal = new VirusTotal(API_KEY);

                        //Use HTTPS instead of HTTP
                        virusTotal.UseTLS = true;
                        if (myStream.Length > 0)
                        {
                            //Check if the file has been scanned before.
                            FileReport report = await virusTotal.GetFileReportAsync(myStream);


                            if (report.ResponseCode == FileReportResponseCode.Present)

                            {


                                foreach (KeyValuePair<string, ScanEngine> scan in report.Scans)

                                {

                                    Console.WriteLine("{0,-25} Detected: {1}", scan.Key, scan.Value.Detected);

                                }

                                Console.WriteLine("Scan ID: " + report.ScanId);

                                Console.WriteLine("Message: " + report.VerboseMsg);
                                Console.WriteLine("Seen before: " + (report.ResponseCode == FileReportResponseCode.Present ? "Yes" : "No"));

                            }
                            addResultRecord(fileLocator.Text, report);
                        }
                        else
                        {
                            MessageBox.Show("Please Select a file having valid size");

                        }

                    }
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);


            }

        }
        public void updateListView()
        {
            scannedFileListView.Items.Clear();
            foreach (var res in resultList)
            {

                var row = new string[] { res.FileName, res.DateOfScan.ToString("MM/dd/yyyy HH:mm:ss"), res.GetChecksum(), res.Result };
                var lvi = new ListViewItem(row);
                lvi.Tag = res;
                scannedFileListView.Items.Add(lvi);

            }
        }

        public void addResultRecord(string filepath,FileReport report)
        {
            string res = "";
            foreach (KeyValuePair<string, ScanEngine> scan in report.Scans)

            {

                res+=string.Format("{0,-25} Detected: {1} \n", scan.Key, scan.Value.Detected);

            }
            ScanResult scr = new ScanResult(filepath, res);
            resultList.Add(scr);
            fileLocator.Text = "";
            updateListView();

        }

        private void FileLocator_DoubleClick(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fileLocator.Text = openFileDialog1.FileName;
                myStream = openFileDialog1.OpenFile();
            }
            
        }

        private void FileLocator_Leave(object sender, EventArgs e)
        {
            if (fileLocator.Text.Length>0)
            {
                if (File.Exists(fileLocator.Text))
                {
                    myStream = File.Open(fileLocator.Text, FileMode.Open);

                }
                else
                {
                    MessageBox.Show("Invalid Path");
                }
            }
        }

        private void FileLocator_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) {
                if (fileLocator.Text.Length > 0)
                {
                    if (File.Exists(fileLocator.Text))
                    {
                        myStream = File.Open(fileLocator.Text, FileMode.Open);

                    }
                    else
                    {
                        MessageBox.Show("Invalid Path");
                    }
                }
            }
        }
    }
}

